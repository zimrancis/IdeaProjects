# spring-boot-hibernate-mysql
How to integrate spring boot with Hibernate and MYSQL
